# knowledgeLLM

A vector-DB–grounded LLM chat workspace. Chat is grounded in a per–knowledge-space
corpus (Slack, Google Docs, GitHub, file uploads) with live citations, a custom
prompt per space, scheduled agents, and RBAC across spaces. Local-first model setup
(Ollama).

## Files

- **knowledgeLLM.dc.html** — the working prototype (login → Ollama setup → app:
  chat with retrieval + sources rail, per-space thread history, Sources/connectors,
  Agents + scheduler, Members/RBAC matrix).
- **Propositions.dc.html** — the exploration canvas: 4 chat concepts + 3 management
  screens, side by side.
- **support.js** — the Design Component runtime both HTML files load. Must sit in the
  same directory as the `.dc.html` files.

## Running

These are self-contained HTML files — no build step. Open either `.dc.html` directly
in a browser, or serve the folder:

```bash
npx serve .
# then open http://localhost:3000/knowledgeLLM.dc.html
```

Keep `support.js` next to the `.dc.html` files (they reference it via `./support.js`).

## Notes

- The chat calls an LLM through the host's `window.claude` bridge when present, and
  falls back to a source-grounded canned answer otherwise. Wire this to your own
  backend / Ollama endpoint to make it production-real.
- All data (spaces, corpus, members, agents, roles) is seeded in-memory inside
  `knowledgeLLM.dc.html` for demonstration.
